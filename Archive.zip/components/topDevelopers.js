export default function TopDevelopers() {
    return(
        <div class="my-10 py-10">
`           <h2 className="my-10 py-10 text-center">Explore <span class="font-semibold">Top Developers</span> on the Map</h2>
            <div class="flex flex-wrap content-wrap">
                <div class="basis-3/12 p-1"><img src="placeholder.png" class="w-full h-full" /></div>
                <div class="basis-5/12 p-1"><img src="placeholder.png" class="w-full h-full" /></div>
                <div class="basis-4/12 p-1"><img src="placeholder.png" class="w-full h-full" /></div>
                <div class="basis-3/12 p-1"><img src="placeholder.png" class="w-full h-full" /></div>
                <div class="basis-4/12 p-1"><img src="placeholder.png" class="w-full h-full" /></div>
                <div class="basis-5/12 p-1"><img src="placeholder.png" class="w-full h-full" /></div>
            </div>`
        </div>
    )
}